@extends('pages.base')

@section('content')

<h1>Contacto</h1>
    
@endsection