@extends('pages.base')

@section('content')

<h1>Inventario</h1>
    
@endsection