@extends('pages.base')

@section('content')

<h1>Lifestyle</h1>
    
@endsection