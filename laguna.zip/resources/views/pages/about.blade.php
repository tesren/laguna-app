@extends('pages.base')

@section('content')

<h1>Nosotros</h1>
    
@endsection