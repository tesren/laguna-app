@extends('pages.base')

@section('content')

<h1>Progreso de la Construcción</h1>
    
@endsection