<?php $__env->startSection('content'); ?>
<?php echo $__env->make('admin.shared.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="c-main">
    <div class="row justify-content-start justify-content-md-center mt-5">
        <div class="col-12 col-md-12 col-lg-11">

            <ul class="nav nav-pills mb-3" id="pills-tab" role="tablist">
                <li class="nav-item" role="presentation">
                  <button class="nav-link active" id="pills-all-tab" data-bs-toggle="pill" data-bs-target="#pills-all" type="button" role="tab" aria-controls="pills-all" aria-selected="true">Todas</button>
                </li>
                <li class="nav-item" role="presentation">
                  <button class="nav-link link-success" id="pills-avaliable-tab" data-bs-toggle="pill" data-bs-target="#pills-avaliable" type="button" role="tab" aria-controls="pills-avaliable" aria-selected="false">Disponibles</button>
                </li>
                <li class="nav-item" role="presentation">
                  <button class="nav-link link-warning" id="pills-hold-tab" data-bs-toggle="pill" data-bs-target="#pills-hold" type="button" role="tab" aria-controls="pills-hold" aria-selected="false">Apartadas</button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link link-danger" id="pills-sold-tab" data-bs-toggle="pill" data-bs-target="#pills-sold" type="button" role="tab" aria-controls="pills-sold" aria-selected="false">Vendidas</button>
                  </li>
              </ul>

              <div class="tab-content" id="pills-tabContent">

                
                <div class="tab-pane fade show active" id="pills-all" role="tabpanel" aria-labelledby="pills-all-tab">

                    <div class="card shadow-7">

                        <div class="card-header d-flex justify-content-between">
                          <span class="fs-5 d-block" style="align-self: center">
                            <i class="far fa-list-alt"></i>
                            Todas las Unidades
                          </span>
                          
                          <a class="btn btn-success d-none d-md-block" href="<?php echo e(route('create.unit')); ?>">Registrar Unidad</a>
                          <a class="btn btn-success d-block d-md-none" href="<?php echo e(route('create.unit')); ?>">Registrar</a>
                        </div>
            
                        <div class="card-body">
                          <div class="table-responsive">
                            <table class="table table-sm table-striped table-bordered w-100" id="all_units_table" data-page-length='10'>
                                <thead>
                                  <tr>
                                    <th>Unidad</th>
                                    <th>Tipo</th>
                                    <th>BR</th>
                                    <th class="d-none d-lg-table-cell">BA</th>
                                    <th class="d-none d-md-table-cell">Torre</th>
                                    <th class="d-none d-lg-table-cell">Nivel</th>
                                    <th>Estado</th>
                                    <th>Precio</th>
                                    <th class="text-center">Acciones</th>
                                  </tr>
                                </thead>
                
                                <tbody>
                                
                                  <?php $__currentLoopData = $units->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($unit->name); ?></td>
                                            <td><?php echo e($unit->unitType->name); ?></td>
                                            <td><?php echo e($unit->unitType->bedrooms); ?></td>
                                            <td class="d-none d-lg-table-cell"><?php echo e($unit->unitType->bathrooms); ?></td>
                                            <td class="d-none d-md-table-cell"><?php echo e($unit->tower->name); ?></td>
                                            <td class="d-none d-lg-table-cell"><?php echo e($unit->floor); ?></td>
                                            <td><?php echo e($unit->status); ?></td>
                                            <td>$<?php echo e(number_format($unit->price)); ?></td>
                                            <td class="d-flex justify-content-center">
                                                <a href="<?php echo e(route('show.unit', ['id' => $unit->id] )); ?>" class="btn btn-primary">Editar</a>
                                            </td>
                                        </tr>
                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
                                </tbody>
                              </table>
                            </div>
                        </div>
                    </div>
                    
                </div>

                
                <div class="tab-pane fade" id="pills-avaliable" role="tabpanel" aria-labelledby="pills-avaliable-tab">
                    <div class="card shadow-7">

                      <div class="card-header d-flex justify-content-between">
                        <span class="fs-5 d-block" style="align-self: center">
                          <i class="far fa-list-alt"></i>
                          Unidades Disponibles
                        </span>
                        
                        <a class="btn btn-success d-none d-md-block" href="<?php echo e(route('create.unit')); ?>">Registrar Unidad</a>
                        <a class="btn btn-success d-block d-md-none" href="<?php echo e(route('create.unit')); ?>">Registrar</a>
                      </div>
            
                        <div class="card-body">
                          <div class="table-responsive">
                            <table class="table table-sm table-striped table-bordered w-100" id="avaliable_units_table" data-page-length='10'>
                                <thead>
                                  <tr>
                                    <th>Unidad</th>
                                    <th>Tipo</th>
                                    <th>BR</th>
                                    <th class="d-none d-lg-table-cell">BA</th>
                                    <th>Torre</th>
                                    <th class="d-none d-lg-table-cell">Nivel</th>
                                    <th>Estado</th>
                                    <th>Precio</th>
                                    <th class="text-center">Acciones</th>
                                  </tr>
                                </thead>
                
                                <tbody>
                                  <?php $avaliableUnits = $units->where('status', 'Disponible'); ?>
                                  <?php $__currentLoopData = $avaliableUnits->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($unit->name); ?></td>
                                            <td><?php echo e($unit->unitType->name); ?></td>
                                            <td><?php echo e($unit->unitType->bedrooms); ?></td>
                                            <td class="d-none d-lg-table-cell"><?php echo e($unit->unitType->bathrooms); ?></td>
                                            <td><?php echo e($unit->tower->name); ?></td>
                                            <td class="d-none d-lg-table-cell"><?php echo e($unit->floor); ?></td>
                                            <td><?php echo e($unit->status); ?></td>
                                            <td>$<?php echo e(number_format($unit->price)); ?></td>
                                            <td class="d-flex justify-content-center">
                                              <a href="<?php echo e(route('show.unit', ['id' => $unit->id] )); ?>" class="btn btn-primary">Editar</a>
                                            </td>
                                        </tr>
                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
                                </tbody>
                              </table>
                            </div>
                        </div>
                    </div>
                </div>

                
                <div class="tab-pane fade" id="pills-hold" role="tabpanel" aria-labelledby="pills-hold-tab">
                    <div class="card shadow-7">

                        <div class="card-header d-flex justify-content-between">
                          <span class="fs-5 d-block" style="align-self: center">
                            <i class="far fa-list-alt"></i>
                            Unidades Apartadas
                          </span>
                          
                          <a class="btn btn-success d-none d-md-block" href="<?php echo e(route('create.unit')); ?>">Registrar Unidad</a>
                          <a class="btn btn-success d-block d-md-none" href="<?php echo e(route('create.unit')); ?>">Registrar</a>
                        </div>
            
                        <div class="card-body">
                          <div class="table-responsive">
                            <table class="table table-sm table-striped table-bordered w-100" id="onHold_units_table" data-page-length='10'>
                                <thead>
                                  <tr>
                                    <th>Unidad</th>
                                    <th>Tipo</th>
                                    <th>BR</th>
                                    <th class="d-none d-lg-table-cell">BA</th>
                                    <th>Torre</th>
                                    <th class="d-none d-lg-table-cell">Nivel</th>
                                    <th>Estado</th>
                                    <th>Precio</th>
                                    <th class="text-center">Acciones</th>
                                  </tr>
                                </thead>
                
                                <tbody>
                                  <?php $onHoldUnits = $units->where('status', 'Apartada'); ?>
                                  <?php $__currentLoopData = $onHoldUnits->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($unit->name); ?></td>
                                            <td><?php echo e($unit->unitType->name); ?></td>
                                            <td><?php echo e($unit->unitType->bedrooms); ?></td>
                                            <td class="d-none d-lg-table-cell"><?php echo e($unit->unitType->bathrooms); ?></td>
                                            <td><?php echo e($unit->tower->name); ?></td>
                                            <td class="d-none d-lg-table-cell"><?php echo e($unit->floor); ?></td>
                                            <td><?php echo e($unit->status); ?></td>
                                            <td>$<?php echo e(number_format($unit->price)); ?></td>
                                            <td class="d-flex justify-content-center">
                                              <a href="<?php echo e(route('show.unit', ['id' => $unit->id] )); ?>" class="btn btn-primary">Editar</a>
                                            </td>
                                        </tr>
                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
                                </tbody>
                              </table>
                            </div>
                        </div>
                    </div>
                </div>

                
                <div class="tab-pane fade" id="pills-sold" role="tabpanel" aria-labelledby="pills-sold-tab">
                    <div class="card shadow-7">

                      <div class="card-header d-flex justify-content-between">
                        <span class="fs-5 d-block" style="align-self: center">
                          <i class="far fa-list-alt"></i>
                          Unidades Vendidas
                        </span>
                        
                        <a class="btn btn-success d-none d-md-block" href="<?php echo e(route('create.unit')); ?>">Registrar Unidad</a>
                        <a class="btn btn-success d-block d-md-none" href="<?php echo e(route('create.unit')); ?>">Registrar</a>
                      </div>
            
                        <div class="card-body">
                          <div class="table-responsive">
                            <table class="table table-sm table-striped table-bordered w-100" id="sold_units_table" data-page-length='10'>
                                <thead>
                                  <tr>
                                    <th>Unidad</th>
                                    <th>Tipo</th>
                                    <th>BR</th>
                                    <th class="d-none d-lg-table-cell">BA</th>
                                    <th>Torre</th>
                                    <th class="d-none d-lg-table-cell">Nivel</th>
                                    <th>Estado</th>
                                    <th>Precio</th>
                                    <th class="text-center">Acciones</th>
                                  </tr>
                                </thead>
                
                                <tbody>
                                  <?php $soldUnits = $units->where('status', 'Vendida'); ?>
                                  <?php $__currentLoopData = $soldUnits->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($unit->name); ?></td>
                                            <td><?php echo e($unit->unitType->name); ?></td>
                                            <td><?php echo e($unit->unitType->bedrooms); ?></td>
                                            <td class="d-none d-lg-table-cell"><?php echo e($unit->unitType->bathrooms); ?></td>
                                            <td><?php echo e($unit->tower->name); ?></td>
                                            <td class="d-none d-lg-table-cell"><?php echo e($unit->floor); ?></td>
                                            <td><?php echo e($unit->status); ?></td>
                                            <td>$<?php echo e(number_format($unit->price)); ?></td>
                                            <td class="d-flex justify-content-center">
                                              <a href="<?php echo e(route('show.unit', ['id' => $unit->id] )); ?>" class="btn btn-primary">Editar</a>
                                            </td>
                                        </tr>
                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
                                </tbody>
                              </table>
                            </div>
                        </div>
                    </div>
                </div>

              </div>

        </div>
    </div>
</div>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript'); ?>

    <script>
        $(document).ready( function () {
            $('#all_units_table').DataTable({
            fixedHeader: {
              header: true,
              footer:false,
            },
            "language": {
              "emptyTable":     "La tabla está vacía",
              "info":           "Mostrando de _START_ a _END_ unidades, de un total de _TOTAL_",
              "infoEmpty":      "Tabla vacía",
              "infoFiltered":   "(filtrado de _MAX_ unidades)",
              "lengthMenu":     "Mostrar _MENU_ unidades",
              "loadingRecords": "Cargando...",
              "processing":     "Cargando...",
              "search":         "Buscar:",
              "zeroRecords":    "No se encontró nada",
              "paginate": {
                  "first":      "Primera",
                  "last":       "Ultima",
                  "next":       "Siguiente",
                  "previous":   "Anterior"
              }
            },
            columnDefs: [
              { orderable: false, targets: 8 }
            ]
        });

        $('#avaliable_units_table').DataTable({
          fixedHeader: {
                header: true,
                footer:false,
            },
            "language": {
              "emptyTable":     "La tabla está vacía",
              "info":           "Mostrando de _START_ a _END_ unidades, de un total de _TOTAL_",
              "infoEmpty":      "Tabla vacía",
              "infoFiltered":   "(filtrado de _MAX_ unidades)",
              "lengthMenu":     "Mostrar _MENU_ unidades",
              "loadingRecords": "Cargando...",
              "processing":     "Cargando...",
              "search":         "Buscar:",
              "zeroRecords":    "No se encontró nada",
              "paginate": {
                  "first":      "Primera",
                  "last":       "Ultima",
                  "next":       "Siguiente",
                  "previous":   "Anterior"
              }
            },
           columnDefs: [
              { orderable: false, targets: 8 }
            ]
        });

        $('#onHold_units_table').DataTable({
          fixedHeader: {
                header: true,
                footer:false,
            },
            "language": {
              "emptyTable":     "La tabla está vacía",
              "info":           "Mostrando de _START_ a _END_ unidades, de un total de _TOTAL_",
              "infoEmpty":      "Tabla vacía",
              "infoFiltered":   "(filtrado de _MAX_ unidades)",
              "lengthMenu":     "Mostrar _MENU_ unidades",
              "loadingRecords": "Cargando...",
              "processing":     "Cargando...",
              "search":         "Buscar:",
              "zeroRecords":    "No se encontró nada",
              "paginate": {
                  "first":      "Primera",
                  "last":       "Ultima",
                  "next":       "Siguiente",
                  "previous":   "Anterior"
              }
            },
           columnDefs: [
              { orderable: false, targets: 8 }
            ]
        });

        $('#sold_units_table').DataTable({
          fixedHeader: {
                header: true,
                footer:false,
            },
            "language": {
              "emptyTable":     "La tabla está vacía",
              "info":           "Mostrando de _START_ a _END_ unidades, de un total de _TOTAL_",
              "infoEmpty":      "Tabla vacía",
              "infoFiltered":   "(filtrado de _MAX_ unidades)",
              "lengthMenu":     "Mostrar _MENU_ unidades",
              "loadingRecords": "Cargando...",
              "processing":     "Cargando...",
              "search":         "Buscar:",
              "zeroRecords":    "No se encontró nada",
              "paginate": {
                  "first":      "Primera",
                  "last":       "Ultima",
                  "next":       "Siguiente",
                  "previous":   "Anterior"
              }
            },
           columnDefs: [
              { orderable: false, targets: 8 }
            ]
        });


        } );
      
    </script>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.base-admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/laguna-app/resources/views/admin/units/index.blade.php ENDPATH**/ ?>