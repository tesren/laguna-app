<?php $__env->startSection('content'); ?>
<?php echo $__env->make('admin.shared.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="c-main">

    <div class="row justify-content-center my-4 my-md-5">

        <?php if(session('message')): ?>
            <div class="col-11 fs-5 my-4 text-center" style="color: #198754;">
                <i class="far fa-check-circle"></i>
                <?php echo e(session('message')); ?>

            </div>
        <?php endif; ?>

        <div class="col-11 col-md-10 col-lg-7 card shadow-7 px-0">

            <div class="card-header d-flex justify-content-between">
                <span class="fs-5 d-block" style="align-self: center">
                <i class="fas fa-hammer"></i>
                 Editar Avance
                </span>
            </div>

            <div class="card-body">
                <form action="<?php echo e(route('update.post',['id'=>$post->id])); ?>" method="post" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <label for="title">Título</label>
                    <input class="form-control mb-3" type="text" name="title" id="title" value="<?php echo e($post->title); ?>" required>

                    <label for="date">Fecha del avance</label>
                    <input class="form-control mb-3" type="date" name="date" id="date" value="<?php echo e($post->date); ?>" required>

                    <label for="description">Descripción</label>
                    <textarea class="form-control mb-3" name="description" id="description" maxlength="500" rows="4" required><?php echo e($post->description); ?></textarea>

                    <?php
                        $progImgs = $imgs->where('size', 'large');                   
                        $i=0;
                    ?>

                    <?php if($progImgs->isNotEmpty()): ?>

                        <label>Imágenes actuales</label>
                        <div id="carouselExampleControls" class="carousel slide mb-3" data-bs-ride="carousel">
                            <div class="carousel-inner">

                                <?php $__currentLoopData = $progImgs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="carousel-item <?php if($i==0): ?> active <?php endif; ?>">
                                        <img src="<?php echo e(asset($img->url)); ?>" class="d-block w-100" alt="Imagenes progreso">
                                    </div>
                                    <?php $i++; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    
                            </div>
                            <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="prev">
                            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                            <span class="visually-hidden">Previous</span>
                            </button>
                            <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="next">
                            <span class="carousel-control-next-icon" aria-hidden="true"></span>
                            <span class="visually-hidden">Next</span>
                            </button>
                        </div>
                    <?php endif; ?>

                    <label for="imgfiles">Seleccione nuevas imágenes del avance</label>
                    <input class="form-control mb-4" type="file" id="imgfiles" name="imgfiles[]" multiple accept=".jpg, .jpeg, .png, .webp, .svg" required>

                    <?php if(session('errors')): ?>
                        <span class="d-block fs-6 mb-3" style="color:#dc3545;">
                            <i class="fas fa-exclamation-circle"></i> La imagen debe pesar menos de 2 MB.
                        </span>
                    <?php endif; ?>

                    <button type="submit" class="btn btn-primary w-100" onclick="this.disabled=true;this.form.submit();">Guardar Cambios</button>
                </form>
            </div>

        </div>

    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.base-admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/laguna-app/resources/views/admin/progress/edit.blade.php ENDPATH**/ ?>