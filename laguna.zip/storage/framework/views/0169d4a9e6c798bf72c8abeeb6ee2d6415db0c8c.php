<?php $__env->startSection('content'); ?>
<?php echo $__env->make('admin.shared.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="c-main">

    <div class="row justify-content-center mt-5">
        <div class="col-11 col-md-11 col-lg-10 card px-0 shadow-8">

            <div class="card-header d-flex justify-content-between">
                <span class="fs-5 d-block" style="align-self: center">
                  <i class="far fa-building"></i>
                  Torres
                </span>
                <a class="btn btn-success" href="<?php echo e(route('create.tower')); ?>">Registrar Torre</a>
            </div>

            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-sm table-striped table-bordered" id="all_towers_table" data-page-length='10'>
                        <thead>
                        <tr>
                            <th>Nombre</th>
                            <th>Unidades</th>
                            <th>Visible</th>
                            <th class="text-center">Acciones</th>
                        </tr>
                        </thead>
        
                        <tbody>
                        
                        <?php $__currentLoopData = $towers->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tower): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($tower->name); ?></td>
                                    <td><?php echo e($tower->units); ?></td>
                                    <td>
                                        <?php if($tower->visible == 0): ?>
                                            No
                                        <?php else: ?>
                                            Si   
                                        <?php endif; ?>
                                    </td>
                                    <td class="d-flex justify-content-center">
                                        <a href="<?php echo e(route('edit.tower',['id'=>$tower->id])); ?>" class="btn btn-primary me-1">Editar</a>

                                        <?php if($tower->visible == 1): ?>
                                            <form action="<?php echo e(route('tower.visible',['id'=>$tower->id])); ?>" method="post">
                                                <?php echo csrf_field(); ?>
                                                <input type="hidden" name="visibility" id="visibility" value="0">
                                                <button type="submit" class="btn btn-success" onclick="this.disabled=true;this.form.submit();"><i class="far fa-eye"></i></button>
                                            </form>
                                        <?php else: ?>
                                            <form action="<?php echo e(route('tower.visible',['id'=>$tower->id])); ?>" method="post">
                                                <?php echo csrf_field(); ?>
                                                <input type="hidden" name="visibility" id="visibility" value="1">
                                                <button type="submit" class="btn btn-danger" onclick="this.disabled=true;this.form.submit();"><i class="far fa-eye-slash"></i></button>
                                            </form>
                                        <?php endif; ?>
                                        
                                    </td>
                                </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
                        </tbody>
                    </table>
                </div>
            </div>

        </div>
    </div>
    
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript'); ?>

    <script>
        $(document).ready( function () {
            $('#all_towers_table').DataTable({
                fixedHeader: {
                        header: true,
                        footer:false,
                    },
                    "language": {
                        "emptyTable":     "La tabla está vacía",
                        "info":           "Mostrando de _START_ a _END_ torres, de un total de _TOTAL_",
                        "infoEmpty":      "Tabla vacía",
                        "infoFiltered":   "(filtrado de _MAX_ torres)",
                        "lengthMenu":     "Mostrar _MENU_ torres",
                        "loadingRecords": "Cargando...",
                        "processing":     "Cargando...",
                        "search":         "Buscar:",
                        "zeroRecords":    "No se encontró nada",
                            "paginate": {
                                "first":      "Primera",
                                "last":       "Ultima",
                                "next":       "Siguiente",
                                "previous":   "Anterior"
                            }
                        },
                columnDefs: [
                    { orderable: false, targets: 3 }
                ]
            });
        });
    </script>
   
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.base-admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/laguna-app/resources/views/admin/towers/index.blade.php ENDPATH**/ ?>