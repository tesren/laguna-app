<!DOCTYPE html>
<html lang="en">

    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <title>Admin Panel</title>

        <!--favicons-->
        <link rel="apple-touch-icon" sizes="180x180" href="<?php echo e(asset('/assets/icons/apple-touch-icon.png')); ?>">
        <link rel="icon" type="image/png" sizes="32x32" href="<?php echo e(asset('/assets/icons/favicon-32x32.png')); ?>">
        <link rel="icon" type="image/png" sizes="16x16" href="<?php echo e(asset('/assets/icons/favicon-16x16.png')); ?>">
        <link rel="manifest" href="<?php echo e(asset('/assets/icons/site.webmanifest')); ?>">
        <link rel="mask-icon" href="<?php echo e(asset('/assets/icons/safari-pinned-tab.svg')); ?>" color="#5bbad5">
        <meta name="msapplication-TileColor" content="#da532c">
        <meta name="theme-color" content="#ffffff">

        <!--bootstrap-->
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('/css/bootstrap.min.css')); ?>"/>
        <!--Styles-->
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('/css/laguna-back.css')); ?>"/>
        
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/datatables.min.css')); ?>"/>
    </head>

    <body>
        
        <div class="d-flex justify-content-center bg-light">
            <?php echo $__env->yieldContent('content'); ?> 
        </div>

        <script src="https://kit.fontawesome.com/164e915f72.js" crossorigin="anonymous"></script>
        <script type="text/javascript" src="<?php echo e(asset('/js/jquery-3.3.1.min.js')); ?>"></script>
        <script type="text/javascript" src="<?php echo e(asset('/js/datatables.min.js')); ?>"></script>
        <script src="<?php echo e(asset('/js/bootstrap.bundle.min.js')); ?>"></script>
        <?php echo $__env->yieldContent('javascript'); ?>

        <?php echo $__env->make('admin.shared.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </body>

</html><?php /**PATH /Applications/MAMP/htdocs/laguna-app/resources/views/admin/base-admin.blade.php ENDPATH**/ ?>