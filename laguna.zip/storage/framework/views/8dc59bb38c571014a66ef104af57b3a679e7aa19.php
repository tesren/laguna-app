<?php $__env->startSection('content'); ?>
<?php echo $__env->make('admin.shared.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="c-main">

    <div class="row justify-content-center my-4 my-md-5">

        <div class="col-11 col-md-10 col-lg-6 card px-0 shadow-8">

            <div class="card-header">
                <i class="fas fa-home"></i>
                Editar Torre: 
                <strong><?php echo e($tower->name); ?></strong>
            </div>

            <div class="card-body">
                <form method="POST" action="<?php echo e(route('update.tower',['id'=>$tower->id])); ?>" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <label for="name">Nombre de la Torre</label>
                    <input class="form-control mb-3" type="text" name="name" id="name" value="<?php echo e($tower->name); ?>" required onchange="enableBtn();">

                    <label for="units">Unidades en venta</label>
                    <input class="form-control mb-3" type="number" min="0" step="1" name="units" id="units" value="<?php echo e($tower->units); ?>" required onchange="enableBtn();">

                    

                    <div class="mb-4">
                        
                        <?php
                            $img = $imgs->where('size', 'large')->first();
                        ?>

                        <?php if(!empty($img->url)): ?>
                            <label class="form-label">Render Actual de la Torre</label>
                            <img class="w-100 mb-3" src="<?php echo e(asset($img->url)); ?>" alt="Imagen">
                        <?php endif; ?>
                        
                        <label for="imgfile" class="form-label d-block">Elige un nuevo render</label>
                        <input class="form-control" type="file" id="imgfile" name="imgfile" accept=".jpg, .jpeg, .png, .webp, .svg" onchange="enableBtn();">
                    </div>

                    <?php if(session('errors')): ?>
                        <span class="d-block fs-6 mb-3" style="color:#dc3545;">
                            <i class="fas fa-exclamation-circle"></i> La imagen debe pesar menos de 2 MB.
                        </span>
                    <?php endif; ?>

                    <button id="update" class="btn btn-primary w-100 disabled" type="submit" onclick="this.disabled=true;this.form.submit();">Guardar Cambios</button>
                </form>
            </div>

        </div>
    </div>

</div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript'); ?>
    <script>

        function enableBtn(){
            $('#update').removeClass('disabled');
        }
        
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.base-admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/laguna-app/resources/views/admin/towers/edit.blade.php ENDPATH**/ ?>