<?php $__env->startSection('content'); ?>

<div class="container-fluid p-0" style="position:relative">

    <h1 class="d-none">Laguna Living</h1>

    <video id="video-agua" src="<?php echo e(asset('/assets/videos/video-ligero.m4v')); ?>" autoplay loop muted>
        Your browser does not support the video tag.
    </video>

    <div class="fondo-verde"></div>

    <img id="logo" src="<?php echo e(asset('/assets/img/logo-dorado.png')); ?>" alt="Logo Laguna Living">

    <h2>COMING SOON</h2>

    <img id="logo-century" src="<?php echo e(asset('/assets/img/logo-century.png')); ?>" alt="Logo Century 21">

</div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('pages.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/laguna-app/resources/views/pages/home.blade.php ENDPATH**/ ?>