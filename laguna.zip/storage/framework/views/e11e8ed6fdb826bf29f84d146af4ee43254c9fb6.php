<footer class="bg-light">
    <div class="d-flex justify-content-end">

        <a class="link-dark me-2 mt-1 text-decoration-none" href="https://punto401.com/" target="_blank" rel="noopener">
            <span class="align-self-center" style="color:#636E72;">Powered by</span> 
            <img width="100px" src="<?php echo e(asset('/assets/icons/punto401.svg')); ?>" alt="Logo Punto401">
        </a>        

    </div>
</footer><?php /**PATH /Applications/MAMP/htdocs/laguna-app/resources/views/admin/shared/footer.blade.php ENDPATH**/ ?>