<?php $__env->startSection('content'); ?>
<?php echo $__env->make('admin.shared.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="c-main">

        <div class="row justify-content-center mt-4 mt-md-5">

            <?php if(session('message')): ?>
                <div class="col-11 fs-5 my-4 text-center" style="color: #198754;">
                    <i class="far fa-check-circle"></i>
                    <?php echo e(session('message')); ?>

                </div>
            <?php endif; ?>

            <div class="col-11 col-md-10 col-lg-8 px-0 card shadow-8">

                <div class="card-header">
                    <i class="fas fa-home"></i>
                    Registrar Unidad
                </div>

                <div class="card-body">

                    <form class="row" action="<?php echo e(route('store.unit')); ?>" method="post" onsubmit="disableButton();">
                        <?php echo csrf_field(); ?>
                        <div class="col-12 col-lg-6 mb-3">
                            <label for="unit">Unidad</label>
                            <input class="form-control" type="text" name="unit" id="unit" required>    
                        </div>

                        <div class="col-12 col-lg-6 mb-3">
                            <label for="type">Tipo</label>
                            <select class="form-select" aria-label="Default select example" name="type" id="type" required onchange="updateInfo();">
                                
                                <option value="" selected>Elige uno</option>
                                <?php $__currentLoopData = $unitTypes->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unitType): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($unitType->id); ?>"><?php echo e($unitType->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                
                            </select>
                        </div>

                        <div class="col-12 col-lg-4 mb-3">
                            <label for="bedrooms">Recámaras</label>
                            <input class="form-control" type="text" name="bedrooms" id="bedrooms" readonly>
                        </div>

                        <div class="col-6 col-lg-2 mb-3">
                            <label for="bathrooms">Baños</label>
                            <input class="form-control" type="text" name="bathrooms" id="bathrooms" readonly>
                        </div>

                        <div class="col-6 col-lg-2 mb-3">
                            <label for="half_baths">Medios baños</label>
                            <input class="form-control" type="text" name="half_baths" id="half_baths" readonly >
                        </div>

                        <div class="col-6 col-lg-4 mb-3">
                            <label for="const">Metros cuadrados</label>
                            <input class="form-control" type="text" name="const" id="const" readonly>
                        </div>

                        <div class="col-6 col-lg-4 mb-3">
                            <label for="tower">Torre</label>
                            <select class="form-select" aria-label="Select Torre" name="tower" id="tower" required>

                                <option value="" selected>Elige uno</option>

                                <?php $__currentLoopData = $towers->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tower): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($tower->id); ?>"><?php echo e($tower->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                
                            </select>
                            
                        </div>

                        <div class="col-6 col-lg-4 mb-3">
                            <label for="status">Estado</label>
                            <select class="form-select" name="status" id="status" required>
                                <option selected value="Disponible">Disponible</option>
                                <option value="Apartada">Apartada</option>
                                <option value="Vendida">Vendida</option>
                            </select>
                        </div>

                        <div class="col-6 col-lg-4 mb-3">
                            <label for="floor">Piso</label>
                            <select class="form-select" name="floor" id="floor" required>

                                <?php for($i=1; $i<21; $i++): ?>
                                    <option value="<?php echo e($i); ?>"><?php echo e($i); ?></option>
                                <?php endfor; ?>

                            </select>
                        </div>

                        <div class="col-12 mb-4">
                            <label for="price">Precio</label>
                            <input class="form-control" type="number" name="price" id="price" required min="0">   
                        </div>

                        <div class="col-12">
                            <button id="store" type="submit" class="btn btn-success w-100">Registrar Unidad</button>
                        </div>

                    </form>

                </div>

            </div>

        </div>


    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript'); ?>
    <script>
        function updateInfo(){
            $(document).ready( function () {

                $.ajax({
                    url: '/admin/unit/types',
                    method: 'POST',
                    data:{
                        id:1,
                        _token:$('input[name="_token"]').val()
                    },
                }).done(function(res){
                    var arrayTypes = JSON.parse(res);
                    //console.log(arrayTypes);

                    for(var j=0; j<arrayTypes.length; j++){
                        if( $('#type').val()  == arrayTypes[j].id){
                            $('#bedrooms').val(arrayTypes[j].bedrooms);
                            $('#bathrooms').val(arrayTypes[j].bathrooms);
                            $('#half_baths').val(arrayTypes[j].half_baths);
                            $('#const').val(arrayTypes[j].meters_total);
                        }
                    }

                });

            });
        }

        function disableButton() {
            var btn = document.getElementById('store');
            btn.disabled = true;
            btn.innerText = 'Cargando...'
        }
        
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.base-admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/laguna-app/resources/views/admin/units/create.blade.php ENDPATH**/ ?>