<?php $__env->startSection('content'); ?>

        <div class="col-12 col-md-8 col-lg-4 text-center pt-5" style="min-height: 95vh">
            <img class="w-100" src="<?php echo e(asset('/assets/img/laguna-logo-negro.png')); ?>" alt="Laguna Logo">

            <div class="card shadow-8 w-100">

                <div class="card-body">

                    <h1 class="mb-4 mt-2 fs-1">Iniciar Sesión</h1>
        
                    <form method="POST" action="">
                        <?php echo csrf_field(); ?>

                        <div class="row">

                            <div class="col-12 mb-3">
                                <span class="d-block text-start secondary-text">Ingresa a tu cuenta</span>
                                <label class="visually-hidden" for="email">Correo</label>
                                <div class="input-group">
                                    <div class="input-group-text">
                                        <i class="far fa-user"></i>
                                    </div>
                                    <input type="email" class="form-control" id="email" name="email" placeholder="Correo Electrónico">
                                </div>
                            </div>

                            <div class="col-12 mb-3">
                                <label class="visually-hidden" for="password">Contraseña</label>
                                <div class="input-group">
                                    <div class="input-group-text">
                                        <i class="fas fa-unlock-alt"></i>
                                    </div>
                                    <input type="text" class="form-control" id="password" name="password" placeholder="Contraseña">
                                </div>
                            </div>

                        </div>

                        <!-- Remember Me -->
                        <div class="row mb-4">
                            <label for="remember_me" class="inline-flex items-start text-start ms-1">
                                <input id="remember_me" type="checkbox" class="text-start" name="remember">
                                <span class="secondary-text">Recuérdame</span>
                            </label>
                        </div>

                        <div class="row">
                        <div class="col-12">
                                <span class="text-danger"><?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
                                
                                <a class="btn w-100 btn-green mb-2" href="<?php echo e(route('dashboard')); ?>">Ingresar</a>
                        </div>
                        </div>

                    </form>

                </div>

                
            </div>

        </div>

    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.base-admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/laguna-app/resources/views/admin/login.blade.php ENDPATH**/ ?>