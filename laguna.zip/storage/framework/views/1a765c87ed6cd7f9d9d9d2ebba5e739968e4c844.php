<?php $__env->startSection('content'); ?>
<?php echo $__env->make('admin.shared.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="c-main">

    <div class="row justify-content-center mt-4 mt-md-5">

        <?php if(session('message')): ?>
            <div class="col-11 fs-5 my-4 text-center" style="color: #198754;">
                <i class="far fa-check-circle"></i>
                <?php echo e(session('message')); ?>

            </div>
        <?php endif; ?>

        <div class="col-11 col-md-10 col-lg-8 card px-0 shadow-8">

            <div class="card-header">
                <i class="far fa-building"></i>
                Registrar Torre
            </div>

            <div class="card-body">
                <form method="POST" action="<?php echo e(route('store.tower')); ?>" enctype="multipart/form-data" onsubmit="disableButton();">
                    <?php echo csrf_field(); ?>
                    <label for="name">Nombre de la Torre</label>
                    <input class="form-control mb-3" type="text" name="name" id="name" required>

                    <label for="units">Unidades en venta</label>
                    <input class="form-control mb-3" type="number" min="0" step="1" name="units" id="units" required>

                    

                    <div class="mb-4">
                        <label for="imgfile" class="form-label">Render de la Torre</label>
                        <input class="form-control" type="file" id="imgfile" name="imgfile" accept=".jpg, .jpeg, .png, .webp, .svg" required>
                    </div>

                    <?php if(session('errors')): ?>
                        <span class="d-block fs-6 mb-3" style="color:#dc3545;">
                            <i class="fas fa-exclamation-circle"></i> La imagen debe pesar menos de 2 MB.
                        </span>
                    <?php endif; ?>

                    <button id="submitBtn" class="btn btn-success w-100" type="submit">Registrar Torre</button>
                </form>
            </div>

        </div>
    </div>

</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript'); ?>
    <script>
        function disableButton() {
            var btn = document.getElementById('submitBtn');
            btn.disabled = true;
            btn.innerText = 'Cargando...'
        }
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.base-admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/laguna-app/resources/views/admin/towers/create.blade.php ENDPATH**/ ?>